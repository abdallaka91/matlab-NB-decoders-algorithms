function H=readalist(fname)

[fid, msg] = fopen(fname,'r','native');

[N,M,count,errmsg] = fscanf(fid,"%d %d\n","C");
[dv,dc,count,errmsg] = fscanf(fid,"%d %d\n","C");
[symDeg,count,errmsg] = fscanf(fid,"%d",N);
[chkDeg,count,errmsg] = fscanf(fid,"%d",M);
[symIdx,count,errmsg] = fscanf(fid,"%d",[dv,N]);

## N
## M
## dv
## dc
## symDeg
## chkDeg
## symIdx

H=zeros(M,N);
for idx=1:N
    for jdx=1:dv
	if (symIdx(jdx,idx)>0)
	   H(symIdx(jdx,idx),idx)=1;
	end
    end
end

