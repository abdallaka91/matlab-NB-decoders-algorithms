# polar-codes-on-MATLAB

This is a simple implementation of polar codes, including encoding, AWGN channel, SC decoding.

I will add more code in future.

# References

[1]	Arikan, Erdal. "Channel polarization: A method for constructing capacity-achieving codes for symmetric binary-input memoryless channels." IEEE Transactions on Information Theory 55.7 (2009): 3051-3073.

[2]	Sarkis, Gabi, et al. "Fast polar decoders: Algorithm and implementation." IEEE Journal on Selected Areas in Communications 32.5 (2014): 946-957.
