function y = de2bi(words, p)
y =  fliplr(dec2bin(words, p) - 48);
